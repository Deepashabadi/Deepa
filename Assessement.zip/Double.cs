﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoublyLinkedList
{


    class Node2
    {
        public int data;

        public Node2 prev;
        public Node2 next;

        public Node2(int ele)
        {
            data = ele;
            next = null;
            prev = null;
        }

    }
    class Double
    {
        public Node2 head;

        public int count;

        public Double()
        {
            head = null;
            count = 0;
        }

        public Node2 createnode(int ele)
        {
            Node2 temp = new Node2(ele);
            temp.data = ele;
            temp.next = null;
            temp.prev = null;
            count++;
            return temp;
        }
        public void insertbegin(int ele)
        {
            Node2 newnode = createnode(ele);
            newnode.next = head;



            if (head != null)
                
                head.prev = newnode;
            head = newnode;
            count++;

        }
        public void insertend(int ele)
        {
            Node2 newnode = createnode(ele);
            if (head == null)
                head = newnode;
            else
            {
                Node2 temp = head;
                while (temp.next != null)
                    temp = temp.next;
                
                temp.next = newnode;
                newnode.prev = temp;
                
            }
            


        }

        public void insertpos(int ele, int pos)
        {
            if (pos == 1)
                insertbegin(ele);
            else if (pos == count )
                insertend(ele);
            
            else
            {
                Node2 newnode = createnode(ele);
                Node2 pn, cn;
                pn = cn = head;
                for (int i = 1; i < pos; i++)
                {
                    pn = cn;
                    cn = cn.next;
                    
                }
                pn.next = newnode;
                newnode.prev = pn;
                newnode.next = cn;
                cn.prev = newnode;
               
            }
            
            
        }
        
        public void deletebegin()
        {
            if (head == null)
                Console.WriteLine("No elements in the list");
            else
            {
                Node2 temp = head;
                head = head.next;

                Console.WriteLine("Deleting the node with value =" + temp.data);
                temp = null;
                count--;
            }

        }
        public void deleteend()
        {
            if (head == null)
                Console.WriteLine("No elements in the list");
            else
            {
                Node2 pn, cn;
                pn = cn = head;
                while (cn.next != null)
                {
                    pn = cn;
                    cn = cn.next;
                }
                if (pn == cn)
                    head = null;
                pn.next = null;
                Console.WriteLine("Deleting the node with value = " + cn.data);
                cn = null;
                count--;
            }
        }
        public void deletepos(int pos)
        {
            if (pos == 1)
                deletebegin();
            else if (pos == count)
                deleteend();
            else if (pos > count)
                Console.WriteLine("Invalid Positions");
            else
            {
                Node2 pn, cn;
                pn = cn = head;
                for (int i = 1; i < pos; i++)
                {
                    pn = cn;
                    cn = cn.next;
                }
                pn.next = cn.next;
                Console.WriteLine("Deleting the node with value = " + cn.data);
                cn = null;
                count--;
            }

        }



        public void findpos(int ele)
        {
            Node2 temp = head;
            int pos = 0;
            while (temp.data != ele && temp.next != null)
            {
                pos++;
                temp = temp.next;
            }

            if (temp.data != ele)
                Console.WriteLine("Given element is not present in the list");
            else
            {

                
                Console.WriteLine("Element found at position = " + (pos + 1));
            }



        }

        public void findposofocc(int ele,int n)
        {
           int count = 0;
            Node2 temp;
            temp = head;
            int pos = 0;
            while(temp != null)
            {
                pos++;
                if(temp.data == ele)
                {
                    count++;
                    if (count == n)
                        Console.WriteLine(" search key found at position =" + pos);

                }
                temp = temp.next;
            }
            if (count == 0)
            {
                Console.WriteLine("search key not found");
            }
            else if(count != n)
            {
                Console.WriteLine("found searchkey but not occurance");
            }


        }










        public void display()
        {
            if (head == null)
                Console.WriteLine("No elements in the list");
            else
            {
                Console.WriteLine("\nElements of list are :");
                Node2 temp;
                temp = head;
                while (temp != null)
                {
                    Console.Write(temp.data + " \t ");
                    temp = temp.next;
                }
                Console.WriteLine();
            }
        }


    }
}



