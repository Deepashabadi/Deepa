﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoublyLinkedList
{
    class Program
    {
        static void Main(string[] args)
        {
            Double d = new Double();
            int ch, ele, pos;
            

            do
            {
                Console.WriteLine("1 :Insert at beginning");
                Console.WriteLine("2 :Insert at end");
                Console.WriteLine("3 :Insert at given position");
                Console.WriteLine("4 :Delete at beginning");
                Console.WriteLine("5 :Delete at end");
                Console.WriteLine("6 :Delete at given position");
                Console.WriteLine("7:Display");
                Console.WriteLine("8: Find the position of given element");
                Console.WriteLine("9 :Find the position of occurence of given element");
                ch = int.Parse(Console.ReadLine());

                switch (ch)
                {
                    case 1:
                        Console.WriteLine("Enter the element = ");
                        ele = int.Parse(Console.ReadLine());
                        d.insertbegin(ele);
                        break;

                    case 2:
                        Console.WriteLine("Enter the element =");
                        ele = int.Parse(Console.ReadLine());
                        d.insertend(ele);
                        break;
                    case 3:
                        Console.WriteLine("Enter the element = ");
                        ele = int.Parse(Console.ReadLine());
                        do
                        {


                            Console.WriteLine(" Enter the position");
                            pos = int.Parse(Console.ReadLine());
                        }
                        while (pos < 1 || pos > d.count +1 );
                        d.insertpos(ele, pos);
                        break;
                    case 4:
                        d.deletebegin();
                        break;
                    case 5:
                        d.deleteend();
                        break;
                    case 6:
                        do
                        {
                            Console.WriteLine("Enter the position");
                            pos = int.Parse(Console.ReadLine());
                        } while (pos < 1 || pos > d.count + 1);
                        d.deletepos(pos);
                        break;

                    case 7:
                        d.display();
                        break;
                    case 8:
                        Console.WriteLine("Enter the element");
                        ele = int.Parse(Console.ReadLine());
                        d.findpos(ele);
                        break;
                    case 9:
                        Console.WriteLine("Enter the element");
                        ele = int.Parse(Console.ReadLine());
                        Console.WriteLine("Enter the occurence");
                        int n= int.Parse(Console.ReadLine());
                        d.findposofocc(ele, n);
                        break;
                }
            } while (ch != 10);
         }
    }
}












            
        
    

